"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_error";
exports.ids = ["pages/_error"];
exports.modules = {

/***/ "./pages/_error.tsx":
/*!**************************!*\
  !*** ./pages/_error.tsx ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nconst Error = ({ statusCode  })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n        children: statusCode ? `An error ${statusCode} occurred on server` : \"An error occurred on client\"\n    }, void 0, false, {\n        fileName: \"/opt/lampp/htdocs/Bunjee/bungee/pages/_error.tsx\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, undefined);\n};\nError.getInitialProps = ({ res , err  })=>{\n    const statusCode = res ? res.statusCode : err ? err.statusCode : 404;\n    return {\n        statusCode\n    };\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Error);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fZXJyb3IudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFFQSxNQUFNQSxRQUFRLENBQUMsRUFBRUMsV0FBVSxFQUFPLEdBQUs7SUFDckMscUJBQ0UsOERBQUNDO2tCQUNFRCxhQUNHLENBQUMsU0FBUyxFQUFFQSxXQUFXLG1CQUFtQixDQUFDLEdBQzNDLDZCQUE2Qjs7Ozs7O0FBR3ZDO0FBRUFELE1BQU1HLGVBQWUsR0FBRyxDQUFDLEVBQUVDLElBQUcsRUFBRUMsSUFBRyxFQUFtQixHQUFLO0lBQ3pELE1BQU1KLGFBQWFHLE1BQU1BLElBQUlILFVBQVUsR0FBR0ksTUFBTUEsSUFBSUosVUFBVSxHQUFHLEdBQUc7SUFDcEUsT0FBTztRQUFFQTtJQUFXO0FBQ3RCO0FBRUEsaUVBQWVELEtBQUtBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yZXZpZXdzLy4vcGFnZXMvX2Vycm9yLnRzeD8yNjA3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5leHRQYWdlQ29udGV4dCB9IGZyb20gXCJuZXh0XCI7XG5cbmNvbnN0IEVycm9yID0gKHsgc3RhdHVzQ29kZSB9OiBhbnkpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8cD5cbiAgICAgIHtzdGF0dXNDb2RlXG4gICAgICAgID8gYEFuIGVycm9yICR7c3RhdHVzQ29kZX0gb2NjdXJyZWQgb24gc2VydmVyYFxuICAgICAgICA6IFwiQW4gZXJyb3Igb2NjdXJyZWQgb24gY2xpZW50XCJ9XG4gICAgPC9wPlxuICApO1xufTtcblxuRXJyb3IuZ2V0SW5pdGlhbFByb3BzID0gKHsgcmVzLCBlcnIgfTogTmV4dFBhZ2VDb250ZXh0KSA9PiB7XG4gIGNvbnN0IHN0YXR1c0NvZGUgPSByZXMgPyByZXMuc3RhdHVzQ29kZSA6IGVyciA/IGVyci5zdGF0dXNDb2RlIDogNDA0O1xuICByZXR1cm4geyBzdGF0dXNDb2RlIH07XG59O1xuXG5leHBvcnQgZGVmYXVsdCBFcnJvcjsiXSwibmFtZXMiOlsiRXJyb3IiLCJzdGF0dXNDb2RlIiwicCIsImdldEluaXRpYWxQcm9wcyIsInJlcyIsImVyciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_error.tsx\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_error.tsx"));
module.exports = __webpack_exports__;

})();