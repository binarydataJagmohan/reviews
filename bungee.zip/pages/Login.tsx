import React from 'react'
import FrontendLogin from '../components/auth/Login';
export default function Login()
{
    return(
        <>
            <FrontendLogin />
        </>
    )
}