import React from 'react'
import FrontendSignUp from '../components/auth/SignUp';
export default function SignUp()
{
    return(
        <>
            <FrontendSignUp />
        </>
    )
}