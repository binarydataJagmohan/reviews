import React from 'react';
import AdminUsers from '../../components/Admin/AllUsers';
export default function Users() {
  return (
        <>
            <AdminUsers/>
        </>
  )
}