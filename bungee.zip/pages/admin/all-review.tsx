import React from 'react'
import Reviews from '../../components/Admin/AllReviews';

export default function reviews()
{
    return(
        <>
            <Reviews />
        </>
    )
}