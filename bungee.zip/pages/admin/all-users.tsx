import React from 'react'
import Users from '../../components/Admin/AllUsers';
export default function users()
{
    return(
        <>
            <Users />
        </>
    )
}