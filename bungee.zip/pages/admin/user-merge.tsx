import React from 'react'
import Usermerge from '../../components/Admin/UserMerge';

export default function reviews()
{
    return(
        <>
            <Usermerge />
        </>
    )
}