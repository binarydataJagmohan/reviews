import React from 'react'
import SingleProfile from '../../components/Admin/SingleProfile';
export default function singleProfile()
{
    return(
        <>
            <SingleProfile />
        </>
    )
}