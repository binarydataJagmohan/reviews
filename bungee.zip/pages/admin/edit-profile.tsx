// EditProfile.js
import EditProfile from '@/components/Admin/EditProfile';
import React from 'react';

export default function EditProfilee() {
  return (
    <>
      <EditProfile />
    </>
  );
}
