import React from 'react'
import Account from '../../components/Admin/MyAccount';

export default function users()
{
    return(
        <>
            <Account />
        </>
    )
}