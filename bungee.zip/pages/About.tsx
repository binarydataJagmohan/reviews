import React from 'react'
import FrontendAbout from '../components/frontend/About';
export default function About()
{
    return(
        <>
            <FrontendAbout />
        </>
    )
}