import React from 'react'
import UserMyAccount from '../../components/User/MyAccount';
export default function MyAccount()
{
    return(
        <>
            <UserMyAccount />
        </>
    )
}