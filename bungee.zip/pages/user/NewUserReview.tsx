import React from 'react'
import UserNewUserReview from '../../components/User/NewUserReview';
export default function NewUserReview()
{
    return(
        <>
            <UserNewUserReview />
        </>
    )
}