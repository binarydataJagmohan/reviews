import React from 'react'
import UserViewProfile from '../../components/User/ViewProfile';
export default function ViewProfile()
{
    return(
        <>
            <UserViewProfile />
        </>
    )
}