import React from 'react'
import UserAddreview from '../../components/User/AddReview';
export default function AddReview()
{
    return(
        <>
            <UserAddreview />
        </>
    )
}