import React from 'react'
import UserEditProfile from '../../components/User/EditProfile';
export default function Test()
{
    return(
        <>
            <UserEditProfile />
        </>
    )
}