import React from 'react'
import UserSearch from '../../components/User/Search';
export default function Search()
{
    return(
        <>
            <UserSearch />
        </>
    )
}