import React from 'react'
import ForgotPassword from '../components/frontend/ForgotPassword';
export default function forgetPassword()
{
    return(
        <>
            <ForgotPassword />
        </>
    )
}