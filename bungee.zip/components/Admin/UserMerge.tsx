import React from 'react'

const UserMerge = () => {
  return (
    <div>UserMerge</div>
  )
}

export default UserMerge