(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5154:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./lib/session.js
var session = __webpack_require__(8923);
;// CONCATENATED MODULE: ./components/layouts/header.tsx
/* eslint-disable @next/next/no-html-link-for-pages */ /* eslint-disable react/jsx-no-comment-textnodes */ 




function Header() {
    const [isAuthenticated, setIsAuthenticated] = (0,external_react_.useState)(false);
    const [initialName, setInitialName] = (0,external_react_.useState)("");
    const router = (0,router_.useRouter)();
    const user_type = "admin";
    const [additionalData, setadditionalData] = (0,external_react_.useState)([]);
    // const [name, setName] = useState('');
    function redirectToLogin() {
        window.location.href = "/Login";
    }
    function handleLogout(e) {
        e.preventDefault();
        (0,session/* removeToken */.gy)();
        (0,session/* removeStorageData */.HB)();
        redirectToLogin();
    }
    (0,external_react_.useEffect)(()=>{
        // alert(localStorage.getItem('id'))
        const token = localStorage.getItem("token");
        const id = localStorage.getItem("id");
        const user_type = localStorage.getItem("user_type");
        if (token && id) {
            setIsAuthenticated(true);
            const firstName = localStorage.getItem("first_name");
            const lastName = localStorage.getItem("last_name");
            if (firstName !== null && lastName !== null) {
                setInitialName(`${firstName.charAt(0).toUpperCase()}${lastName.charAt(0).toUpperCase()}`);
            }
        }
    }, []);
    // useEffect(() => {
    //   const user_id = localStorage.getItem('id');
    //   getEditdata(user_id).then((res)=>{
    //     console.log(res);
    //    setadditionalData(res.data);
    //   });
    // }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("header", {
            className: "header-head dasktop-view",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                    className: "navbar navbar-expand-lg navbar-light ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            className: "navbar-brand",
                            href: "/index",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "https://bungeenetwork.com/" + "assets/images/logo-white.png",
                                alt: "logo-white",
                                className: "logo dasktop"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "navbar-toggler",
                            type: "button",
                            "data-bs-toggle": "collapse",
                            "data-bs-target": "#navbarSupportedContent",
                            "aria-controls": "navbarSupportedContent",
                            "aria-expanded": "false",
                            "aria-label": "Toggle navigation",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "navbar-toggler-icon"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "collapse navbar-collapse",
                            id: "navbarSupportedContent",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "navbar-nav ms-auto mb-lg-0 dasktop-menu",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "nav-link active",
                                                "aria-current": "page",
                                                href: "/index",
                                                children: "Home"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "nav-link",
                                                href: "/About",
                                                children: "About Bungee"
                                            })
                                        }),
                                        isAuthenticated ? /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "nav-link",
                                                href: "/user/search",
                                                children: "Search Reviews"
                                            })
                                        }) : ""
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "navbar-nav ms-auto mb-lg-0 tab-mobile-menu",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                className: "nav-link active",
                                                "aria-current": "page",
                                                href: "#",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa-solid fa-house"
                                                    }),
                                                    " Home"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                className: "nav-link",
                                                href: "search-reviews.html",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa-solid fa-magnifying-glass"
                                                    }),
                                                    " Search Reviews"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                className: "nav-link",
                                                href: "about-bungee.html",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa-solid fa-question"
                                                    }),
                                                    " About Bungee"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                className: "nav-link",
                                                href: "view-profile.html",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa-solid fa-user"
                                                    }),
                                                    " View your profile "
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                isAuthenticated ? /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                    className: "d-flex"
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                    className: "d-flex",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/Login",
                                        className: "btn btn-all header-btn",
                                        children: " Login"
                                    })
                                }),
                                isAuthenticated ? /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                    className: "d-flex",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/user/MyAccount",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "btn btn-all header-btn top-header-btn set",
                                            children: [
                                                " ",
                                                initialName
                                            ]
                                        })
                                    })
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                    className: "d-flex"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "navbar-brand",
                            href: "#",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "https://bungeenetwork.com/" + "assets/images/logo-white.png",
                                alt: "logo-white",
                                className: "logo mobile-view"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "user-profile mobile-view",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "btn btn-all header-btn top-header-btn",
                                children: [
                                    " ",
                                    initialName
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/layouts/footer.tsx



function Footer() {
    const [isAuthenticated, setIsAuthenticated] = (0,external_react_.useState)(false);
    const [initialName, setInitialName] = (0,external_react_.useState)("");
    const router = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        // alert(localStorage.getItem('id'))
        const token = localStorage.getItem("token");
        const id = localStorage.getItem("id");
        if (token && id) {
            setIsAuthenticated(true);
        }
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: isAuthenticated ? /*#__PURE__*/ jsx_runtime_.jsx("footer", {
            className: "footer-part",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/index",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/user/MyAccount",
                                children: "My Account"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/user/search",
                                children: "Search Review"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/About",
                                children: "About us"
                            })
                        })
                    ]
                })
            })
        }) : /*#__PURE__*/ jsx_runtime_.jsx("footer", {
            className: "footer-part",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/index",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/Login",
                                children: "Login"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/SignUp",
                                children: "Sign up"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "/About",
                                children: "About us"
                            })
                        })
                    ]
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/layouts/layout.tsx




function Layout({ children , ...props }) {
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "wrapper",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                ...props,
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
        ]
    });
}

;// CONCATENATED MODULE: ./components/Admin/layouts/header.tsx
/* eslint-disable @next/next/no-img-element */ /* eslint-disable @next/next/no-html-link-for-pages */ /* eslint-disable react/jsx-no-comment-textnodes */ 



function header_Header() {
    const [isAuthenticated, setIsAuthenticated] = (0,external_react_.useState)(false);
    const [initialName, setInitialName] = (0,external_react_.useState)("");
    const router = (0,router_.useRouter)();
    const user_type = "admin";
    const [additionalData, setadditionalData] = (0,external_react_.useState)([]);
    // const [name, setName] = useState('');
    function redirectToLogin() {
        window.location.href = "/Login";
    }
    (0,external_react_.useEffect)(()=>{
        // alert(localStorage.getItem('id'))
        const token = localStorage.getItem("token");
        const id = localStorage.getItem("id");
        const user_type = localStorage.getItem("user_type");
        if (token && id) {
            setIsAuthenticated(true);
            const firstName = localStorage.getItem("first_name");
            const lastName = localStorage.getItem("last_name");
            if (firstName !== null && lastName !== null) {
                setInitialName(`${firstName.charAt(0).toUpperCase()}${lastName.charAt(0).toUpperCase()}`);
            }
        }
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("header", {
            className: "header-head dasktop-view",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                    className: "navbar navbar-expand-lg navbar-light ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            className: "navbar-brand",
                            href: "/admin/all-users",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "https://bungeenetwork.com/" + "assets/images/logo-white.png",
                                alt: "logo-white",
                                className: "logo dasktop"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "navbar-toggler",
                            type: "button",
                            "data-bs-toggle": "collapse",
                            "data-bs-target": "#navbarSupportedContent",
                            "aria-controls": "navbarSupportedContent",
                            "aria-expanded": "false",
                            "aria-label": "Toggle navigation",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "navbar-toggler-icon"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "collapse navbar-collapse",
                            id: "navbarSupportedContent",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "navbar-nav ms-auto mb-lg-0 dasktop-menu",
                                    children: [
                                        isAuthenticated && user_type == "admin" ? /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "nav-link active",
                                                "aria-current": "page",
                                                href: "/admin/all-users",
                                                children: "All Users"
                                            })
                                        }) : "",
                                        isAuthenticated && user_type == "admin" ? /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "nav-link active",
                                                "aria-current": "page",
                                                href: "/admin/all-review",
                                                children: "All Reviews"
                                            })
                                        }) : ""
                                    ]
                                }),
                                isAuthenticated && user_type == "admin" ? /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                    className: "d-flex"
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                    className: "d-flex",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "/Login",
                                        className: "btn btn-all header-btn",
                                        children: " Login"
                                    })
                                }),
                                isAuthenticated && user_type == "admin" ? /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                    className: "d-flex",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/admin/my-account",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "btn btn-all header-btn top-header-btn set",
                                            children: [
                                                " ",
                                                initialName
                                            ]
                                        })
                                    })
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                    className: "d-flex"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "navbar-brand",
                            href: "#",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "https://bungeenetwork.com/" + "assets/images/logo-white.png",
                                alt: "logo-white",
                                className: "logo mobile-view"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "user-profile mobile-view",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "btn btn-all header-btn top-header-btn",
                                children: [
                                    " ",
                                    initialName
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/Admin/layouts/footer.tsx




function footer_Footer() {
    const [isAuthenticated, setIsAuthenticated] = (0,external_react_.useState)(false);
    const [initialName, setInitialName] = (0,external_react_.useState)("");
    const router = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        // alert(localStorage.getItem('id'))
        const token = localStorage.getItem("token");
        const id = localStorage.getItem("id");
        if (token && id) {
            setIsAuthenticated(true);
        }
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: isAuthenticated ? /*#__PURE__*/ jsx_runtime_.jsx("footer", {
            className: "footer-part",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/index",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/user/MyAccount",
                                children: "My Account"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/user/search",
                                children: "Search Review"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/About",
                                children: "About us"
                            })
                        })
                    ]
                })
            })
        }) : /*#__PURE__*/ jsx_runtime_.jsx("footer", {
            className: "footer-part",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/index",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/Login",
                                children: "Login"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/SignUp",
                                children: "Sign up"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/About",
                                children: "About us"
                            })
                        })
                    ]
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/Admin/layouts/layout.tsx




function layout_Layout({ children , ...props }) {
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "wrapper",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                ...props,
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer_Footer, {})
        ]
    });
}

;// CONCATENATED MODULE: ./pages/_app.tsx






function App({ Component , pageProps  }) {
    const router = (0,router_.useRouter)();
    if (router.pathname.startsWith("/admin")) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("title", {
                            children: "Admin Dashboard"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            charSet: "utf-8"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            name: "viewport",
                            content: "width=device-width, initial-scale=1"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(layout_Layout, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                })
            ]
        });
    // } else if (router.pathname.startsWith("/user")) {
    //   return(
    //     <>
    //       <Head>
    //         <title>Admin Dashboard</title>  
    //         <meta charSet="utf-8"/>
    //         <meta name="viewport" content="width=device-width, initial-scale=1"/>    
    //       </Head>
    //       <Component {...pageProps} />
    //     </>
    //   ) 
    } else {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("title", {
                            children: "Bunjee"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            charSet: "utf-8"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            name: "viewport",
                            content: "width=device-width, initial-scale=1"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Layout, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                })
            ]
        });
    }
}


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664,923], () => (__webpack_exec__(5154)));
module.exports = __webpack_exports__;

})();