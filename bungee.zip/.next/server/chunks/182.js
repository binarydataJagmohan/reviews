exports.id = 182;
exports.ids = [182];
exports.modules = {

/***/ 3579:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Home_main__nLjiQ",
	"description": "Home_description__41Owk",
	"code": "Home_code__suPER",
	"grid": "Home_grid__GxQ85",
	"card": "Home_card___LpL1",
	"center": "Home_center__4BFgC",
	"logo": "Home_logo__27_tb",
	"thirteen": "Home_thirteen__cMI_k",
	"rotate": "Home_rotate____XsI",
	"content": "Home_content__Zy02X",
	"vercelLogo": "Home_vercelLogo__dtSk9",
	"pagination": "Home_pagination__DFWeN",
	"pageLink": "Home_pageLink__s15iA",
	"pageItem": "Home_pageItem__iIeDc",
	"pageItemActive": "Home_pageItemActive__lGNNa"
};


/***/ }),

/***/ 8869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3579);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1__);


const Pagination = ({ items , pageSize , currentPage , onPageChange  })=>{
    const pagesCount = Math.ceil(items.length / pageSize); // Use `items.length` to get the length of the array
    if (pagesCount === 1) return null;
    const pages = Array.from({
        length: pagesCount
    }, (_, i)=>i + 1);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1___default().pagination),
            children: pages.map((page)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: page === currentPage ? (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1___default().pageItemActive) : (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1___default().pageItem),
                    onClick: ()=>onPageChange(page),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1___default().pageLink),
                        children: page
                    })
                }, page))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pagination);


/***/ }),

/***/ 1976:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ paginate)
/* harmony export */ });
const paginate = (items, pageNumber, pageSize)=>{
    const startIndex = (pageNumber - 1) * pageSize;
    return items.slice(startIndex, startIndex + pageSize);
};


/***/ })

};
;