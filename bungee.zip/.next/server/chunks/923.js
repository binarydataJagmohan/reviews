"use strict";
exports.id = 923;
exports.ids = [923];
exports.modules = {

/***/ 8923:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HB": () => (/* binding */ removeStorageData),
/* harmony export */   "LP": () => (/* binding */ getToken),
/* harmony export */   "Ts": () => (/* binding */ getCurrentUserData),
/* harmony export */   "gy": () => (/* binding */ removeToken)
/* harmony export */ });
/**
 * * Remove stored token
 * It should remove the Token into the SessionStorage or LocalStorage
 *
 * @returns {void}
 */ function removeToken() {
    window.localStorage.removeItem("token");
    window.sessionStorage.removeItem("token");
}
function removeStorageData() {
    window.localStorage.removeItem("id");
    window.localStorage.removeItem("first_name");
    window.localStorage.removeItem("last_name");
    window.localStorage.removeItem("email");
    window.localStorage.removeItem("set_name");
    window.localStorage.removeItem("user_type");
}
/**
 * * Get the Token if presents.
 *
 * @returns {string | undefined}
 */ function getToken() {
    return window.localStorage.getItem("token") || window.sessionStorage.getItem("token");
}
function getCurrentUserData() {
    if (false) {} else {
        const current_user_data = {};
        return current_user_data;
    }
}


/***/ })

};
;