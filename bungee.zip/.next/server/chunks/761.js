exports.id = 761;
exports.ids = [761];
exports.modules = {

/***/ 7097:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c0": () => (/* binding */ resetPassword),
/* harmony export */   "o9": () => (/* binding */ forgetPassword),
/* harmony export */   "x4": () => (/* binding */ login),
/* harmony export */   "z2": () => (/* binding */ register)
/* harmony export */ });
/* unused harmony export getAllReviews */
/* harmony import */ var _session__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8923);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const login = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/login", {
            method: "post",
            headers: {
                "Accept": "application/json",
                "Authorization": "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            },
            data: {
                ...data
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const register = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/register", {
            method: "post",
            headers: {
                "Accept": "application/json"
            },
            data: {
                ...data
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const forgetPassword = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request(`${"http://127.0.0.1:8000/api"}/forget-password`, {
            email: data,
            method: "post",
            headers: {
                "Accept": "application/json"
            },
            data: {
                ...data
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const resetPassword = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request(`${"http://127.0.0.1:8000/api"}/reset-password`, {
            data: data,
            method: "post",
            headers: {
                "Accept": "application/json"
            },
            data: {
                ...data
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const getAllReviews = async ()=>{
    return new Promise((resolve, reject)=>{
        const req = axios.request(`${"http://127.0.0.1:8000/api"}/getallreview`, {
            method: "get",
            headers: {
                "Accept": "application/json"
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
}; // export const getCurrentUserData = async (data) => {
 //   return new Promise((resolve, reject) => {
 //     const req = axios.request(process.env.NEXT_PUBLIC_API_URL+'/getcurrentuserdata', {
 //       method: 'get',
 //       headers: {
 //           'Accept': 'application/json',
 //           'Authorization': 'Bearer '+getToken()
 //       },
 //       params: {
 //         ...data
 //       },
 //     });
 //     req.then(res => resolve(res.data))
 //       .catch(err => reject(err));
 //   });
 // };

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ })

};
;