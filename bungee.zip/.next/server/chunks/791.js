"use strict";
exports.id = 791;
exports.ids = [791];
exports.modules = {

/***/ 4791:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dx": () => (/* binding */ LikeReview),
/* harmony export */   "FJ": () => (/* binding */ getbunjeeScore),
/* harmony export */   "G2": () => (/* binding */ mostLikedReviews),
/* harmony export */   "JN": () => (/* binding */ saveAdminProfileData),
/* harmony export */   "Lt": () => (/* binding */ getUserProfileData),
/* harmony export */   "OC": () => (/* binding */ EditProfileData),
/* harmony export */   "Qz": () => (/* binding */ getEditdata),
/* harmony export */   "UE": () => (/* binding */ getallUsers),
/* harmony export */   "Wb": () => (/* binding */ getLatestReviews),
/* harmony export */   "eL": () => (/* binding */ newuserreview),
/* harmony export */   "h8": () => (/* binding */ deleteUser),
/* harmony export */   "tT": () => (/* binding */ deleteReviews),
/* harmony export */   "uq": () => (/* binding */ getUserProfileDatabyid),
/* harmony export */   "xi": () => (/* binding */ submitReview),
/* harmony export */   "yT": () => (/* binding */ getSearchedResults)
/* harmony export */ });
/* unused harmony exports getownreviews, UserMerge, samename */
/* harmony import */ var _session__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8923);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const getUserProfileDatabyid = async (id)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/get-user-profile-data-id/" + id, {
            method: "get",
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const getUserProfileData = async (slug)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/get-user-profile-data/" + slug, {
            method: "get",
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const saveAdminProfileData = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/update-profile-data", {
            method: "post",
            data: data,
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
// export const getSearchedResults = async (query) => {
//   return new Promise((resolve, reject) => {
//     const req = axios.request(process.env.NEXT_PUBLIC_API_URL + '/search/?q=' + query, {
//       method: 'get',
//       headers: {
//         'Accept': 'application/json',
//         'Authorization': 'Bearer ' + getToken()
//       },
//     });
//     req.then(res => resolve(res.data))
//       .catch(err => reject(err));
//   });
// };
const getSearchedResults = async (query, slug)=>{
    return new Promise((resolve, reject)=>{
        const url = slug ? "http://127.0.0.1:8000/api" + `/search/${slug}` : "http://127.0.0.1:8000/api" + "/search/?q=" + query;
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request(url, {
            method: "get",
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const getLatestReviews = async ()=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/getallreview", {
            method: "get",
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const submitReview = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/savereview", {
            method: "post",
            data: data,
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const getownreviews = async (id)=>{
    return new Promise((resolve, reject)=>{
        const req = axios.request("http://127.0.0.1:8000/api" + "/my_reviews/" + id, {
            method: "get",
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + getToken()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const LikeReview = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/like-review", {
            method: "post",
            data: data,
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const newuserreview = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/new_user_review", {
            method: "post",
            data: data,
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const deleteReviews = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/delete-reviews", {
            method: "post",
            data: {
                id: data
            },
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const mostLikedReviews = async ()=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/most-liked-review", {
            method: "get",
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const getallUsers = async ()=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/get-all-users", {
            method: "get",
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const EditProfileData = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/edit-profile", {
            method: "post",
            data: data,
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const getEditdata = async (id)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/get-edit-profile-data/" + id, {
            method: "get",
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
// export const getlikedislike = async (userId) => {
//   return new Promise((resolve, reject) => {
//     const req = axios.request(process.env.NEXT_PUBLIC_API_URL+'/getlikedislikes/'+userId, {
//       method: 'get',
//       headers: {
//           'Accept': 'application/json',
//           'Authorization': 'Bearer '+getToken()
//       },
//     });
//     req.then(res => resolve(res.data))
//       .catch(err => reject(err));
//   });
// };
const getbunjeeScore = async ()=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/get-bunjee-score", {
            method: "get",
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const deleteUser = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios__WEBPACK_IMPORTED_MODULE_0__["default"].request("http://127.0.0.1:8000/api" + "/users", {
            method: "post",
            data: {
                id: data
            },
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + (0,_session__WEBPACK_IMPORTED_MODULE_1__/* .getToken */ .LP)()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const UserMerge = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios.request("http://127.0.0.1:8000/api" + "/users/merge", {
            method: "post",
            data: data,
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + getToken()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};
const samename = async (data)=>{
    return new Promise((resolve, reject)=>{
        const req = axios.request("http://127.0.0.1:8000/api" + "/users/same-name", {
            method: "get",
            data: data,
            headers: {
                Accept: "application/json",
                Authorization: "Bearer " + getToken()
            }
        });
        req.then((res)=>resolve(res.data)).catch((err)=>reject(err));
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;